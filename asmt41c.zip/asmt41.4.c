#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#include<io.h>
#define FILESIZE 1024

int CountChar(char Fname[],char Alpha)
{
	int fd=0;
	int iRet=0;
	int iCnt=0;
	int Number=0;
	char Buffer[FILESIZE];
	
	
	
	
	fd=open(Fname,O_RDONLY);
	
	if(fd==-1)
	{
		printf("unable to open  the file\n");
		return -1;
	}
	
	
	while((iRet=read(fd,Buffer,sizeof(Buffer)))!=0)
	{
		for(iCnt=0; iCnt<iRet; iCnt++)
		{
			
			if(Buffer[iCnt]==Alpha)
			{
				break;
			}
			Number++;
				
		}
	}
	
	return Number;
	
	close(fd);
	
}

int main()
{
	char Fname[20];
	int iRet=0;
	char Alphabet='\0';
	
	printf("enter the file open\n");
	scanf("%s",Fname);
	
	printf("enter the character that you want to count frequency\n");
	scanf(" %c",&Alphabet);
	
	iRet=CountChar(Fname,Alphabet);
	printf("the frequency of characters are : %d",iRet);
	
	return 0;
}