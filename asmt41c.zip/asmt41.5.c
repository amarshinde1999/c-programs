#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#include<io.h>
#define FILESIZE 1024

void DisplayN(char Fname[],int iSize)
{
	int fd=0;
	int iRet=0;
	int iCnt=0;
	int Number=0;
	char Buffer[FILESIZE];
	
	
	
	
	fd=open(Fname,O_RDONLY);
	
	if(fd==-1)
	{
		printf("unable to open  the file\n");
	
	}
	
	iRet=read(fd,Buffer,iSize);
	
		printf("data from file is \n");
		
		write(1,Buffer,iRet);
		
		close(fd);

			
}

	
	


int main()
{
	char Filename[20];
	int iRet=0;
	int iValue=0;
	
	printf("enter the file open\n");
	scanf("%s",Filename);
	
	printf("enter the count of data that you want to display\n");
	scanf("%d",&iValue);
	
	DisplayN(Filename,iValue);
	
	return 0;
}