#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#include<io.h>
#define FILESIZE 1024

int CountCapital(char Fname[])
{
	int fd=0;
	int iRet=0;
	int iCnt=0;
	int Number=0;
	char Buffer[FILESIZE];
	
	
	
	
	fd=open(Fname,O_RDONLY);
	
	if(fd==-1)
	{
		printf("unable to open  the file\n");
		return -1;
	}
	
	printf("file is successfully opened %d\n",fd);
	
	
	while((iRet=read(fd,Buffer,sizeof(Buffer)))!=0)
	{
		for(iCnt=0; iCnt<iRet; iCnt++)
		{
			if(Buffer[iCnt]>='A' && Buffer[iCnt]<='Z')
				Number++;
		}
	}
	
	return Number;
	
	close(fd);
	
}

int main()
{
	char Fname[20];
	int iRet=0;
	
	printf("enter the file open\n");
	scanf("%s",Fname);
	
	iRet=CountCapital(Fname);
	printf("the number of capital characters are : %d",iRet);
	
	return 0;
}