#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

int Fileopen(char Fname[])
{
	int fd=0;
	int iRet=0;
	char Buffer[30];
	
	
	fd=creat(Fname,0777);
	
	if(fd==-1)
	{
		printf("unable to create  the file\n");
		return -1;
	}
	
	printf("file is successfully created\n");
	
	close(fd);
	
}

int main()
{
	char Fname[20];
	
	printf("enter the file name that  you want to create \n");
	scanf("%s",Fname);
	
	Fileopen(Fname);
	
	return 0;
}