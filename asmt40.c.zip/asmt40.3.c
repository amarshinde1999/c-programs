#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#define FILESIZE 1024

int Fileread(char Fname[])
{
	int fd=0;
	int iRet=0;
	char Buffer[FILESIZE];
	
	
	fd=open(Fname,O_RDONLY);
	
	if(fd==-1)
	{
		printf("unable to open  the file\n");
		return -1;
	}
	
	printf("file is successfully opened\n");
	
	iRet=read(fd,Buffer,5);
	printf("%s\n data from file ",Buffer);
	
	close(fd);
	
}

int main()
{
	char Fname[20];
	
	printf("enter the file name that  you want to read \n");
	scanf("%s",Fname);
	
	Fileread(Fname);
	
	return 0;
}