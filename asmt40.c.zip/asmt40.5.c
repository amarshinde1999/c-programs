#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
#define FILESIZE 1024

int FileOper(char Fname[])
{
	int fd=0;
	int iRet=0;
	char Buffer[FILESIZE];
	
	
	
	
	fd=open(Fname,O_RDWR| O_APPEND);
	
	if(fd==-1)
	{
		printf("unable to open  the file\n");
		return -1;
	}
	
	printf("file is successfully opened %d\n",fd);
	
	printf("enter the data that you want to write\n");
	scanf(" %[^'\n']s",Buffer);
	
	iRet=write(fd,Buffer,strlen(Buffer));
	printf("%d  bytes data written in file ",iRet);
	
	close(fd);
	
}

int main()
{
	char Fname[20];
	
	printf("enter the file name that  you want to open\n");
	scanf("%s",Fname);
	
	FileOper(Fname);
	
	return 0;
}